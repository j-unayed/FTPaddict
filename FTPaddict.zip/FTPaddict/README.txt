FTPaddict V10
=========

FTPaddict is a powerful tool designed for easy streaming and downloading of videos from FTP servers.

**Important!**
--------------
- **Don’t delete** the `_internal` folder or its contents. Doing so will cause the program to crash!
- Windows Defender might flag the app as malware the first time you run it. This happens because of the way the app was packaged. Click `Run Anyway` or add an exception in your security settings.

Navigation:
-----------
- **Access FTP Servers**: Click on an FTP shortcut or enter a custom FTP URL in the search bar and click `Go`.
- **Browse**: Navigate folders and files like a standard file manager.
- **History**: Click `Browsing History` on the homepage to view history. Click `Clear` on the history page to delete all entries.
- **Search**: Use the search bar to find folders. Navigate to a Video List Folder to stream or download.

Streaming and Downloading:
--------------------------
- **Stream Tab**: Choose your media player (VLC, PotPlayer, or KMPlayer) and click on a video to start streaming.
- **Download Tab**: 
   - Click on a video to download it.
   - Specify a range of videos (from and to) and click `Download`.
   - Click `Download All` to download all videos in a folder.

*Downloaded videos can be found in the `Downloaded Videos` folder inside the program directory.*

Customizing FTPaddict:
----------------------
- **Edit Shortcuts**: Modify, add, or delete shortcuts (up to five). Click `Save Shortcuts` to apply changes.
- **Reset Shortcuts**: Click `Reset Shortcuts` to revert to the default shortcuts.

Version Info:
-------------
- **Version**: V10
- **Release Date**: October 5, 2024
- **Changelog**: 
   - Added "Download All" feature to the download tab.
   - Improved navigation and history management.
   - Enhanced playlist creation for video streaming.

Contact Me:
-----------
For suggestions or if you encounter any errors, feel free to reach out:

- **Email**: mdjunayed733@gmail.com
- **Facebook**: http://m.me/junayed733/
- **Support Me**: 01728078733 (bKash/Rocket)
